import java.awt.Color;
import java.util.*;

// generic search class, for abstracting purposes
abstract class Search {
  // conduct a search on that maze and update its visited and path fields
  public abstract void search(MazeWorld maze);
}

// DFS class
class DFS extends Search {
  Stack<Cell> worklist;
  HashMap<Cell, Cell> visited;

  DFS(Cell start) {
    this.worklist = new Stack<Cell>();
    this.worklist.push(start);
    visited = new HashMap<>();
  }

  // conducts a DFS
  // EFFECT: conduct a DFS on that maze and update the path and visited cells
  public void search(MazeWorld maze) {
    visited.put(maze.start, maze.start);
    maze.current.gotVisited();
    // while (current != maze.end) {
    ArrayList<Cell> adjacents = maze.current.neighbors;
    for (Cell c : adjacents) {
      if (!visited.containsKey(c)) {
        visited.put(c, maze.current);
        // c.gotVisited();
        this.worklist.push(c);
      }
    }
    while (maze.current.visited) {
      maze.current = this.worklist.pop();
    }
    // }
    maze.path.addFirst(maze.current);
    if (maze.current.equals(maze.end)) {
      while (maze.current != maze.start) {
        maze.current.changeColor(Color.cyan);
        maze.current = visited.get(maze.current);
        maze.path.addFirst(maze.current);
      }
    }
  }
}

// BFS class
class BFS extends Search {
  Queue<Cell> worklist;
  HashMap<Cell, Cell> visited;

  BFS(Cell start) {
    this.worklist = new LinkedList<Cell>();
    this.visited = new HashMap<Cell, Cell>();
  }

  // conducts a BFS
  // EFFECT: conduct a BFS on that maze and update the path and visited cells
  public void search(MazeWorld maze) {
    this.visited.put(maze.start, maze.start);
    maze.current.gotVisited();
    // while (current != maze.end) {
    ArrayList<Cell> adjacents = maze.current.neighbors;
    for (Cell c : adjacents) {
      if (!this.visited.containsKey(c)) {
        this.visited.put(c, maze.current);
        // c.gotVisited();
        this.worklist.add(c);
      }
    }
    while (maze.current.visited) {
      maze.current = this.worklist.remove();
    }
    // }
    maze.path.addFirst(maze.current);
    if (maze.current.equals(maze.end)) {
      while (maze.current != maze.start) {
        maze.current.changeColor(Color.cyan);
        maze.current = visited.get(maze.current);
        maze.path.addFirst(maze.current);
      }
    }
  }
}