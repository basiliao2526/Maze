import java.awt.Color;
import java.util.*;
import javalib.impworld.WorldScene;
import javalib.worldimages.*;
import tester.Tester;

//examples class
class ExamplesMaze {

  MazeWorld maze1;
  MazeWorld maze2;
  MazeWorld maze3;
  MazeWorld maze4;
  MazeWorld maze5;
  MazeWorld maze6;
  MazeWorld maze7;
  MazeWorld maze8;
  WorldScene s1;
  WorldScene s2;
  WorldScene s3;
  MTCell mtCell;
  Cell cell1;
  Cell cell2;
  Cell cell3;
  Cell cell4;
  Cell cell5;
  Cell cell6;
  Edge edge1;
  Edge edge2;
  Edge edge3;
  Edge edge4;
  EdgeComparator ec;
  HashMap<Cell, Cell> hash;

  // initialize everything here to avoid errors in testing
  void initData() {
    // (horizontal, vertical) -> (width, length) -> (cols, rows)
    maze1 = new MazeWorld(100, 60);
    maze2 = new MazeWorld(100, 4);
    maze3 = new MazeWorld(4, 4);
    maze4 = new MazeWorld(50);
    maze5 = new MazeWorld(60, 50);
    maze6 = new MazeWorld(30, 50);
    maze7 = new MazeWorld(30);
    maze8 = new MazeWorld(40);

    s1 = new WorldScene(1001, 601);
    s2 = new WorldScene(1001, 601);
    s3 = new WorldScene(1001, 601);

    mtCell = new MTCell();
    cell1 = new Cell(0, 0, 4, 4);
    cell2 = new Cell(1, 2, 6, 8);
    cell3 = new Cell(5, 0, 30, 30);
    cell4 = new Cell(10, 2, 2, 8);
    cell5 = new Cell(16, 7, 15, 20);
    cell6 = new Cell(28, 3, 9, 6);

    edge1 = new Edge(cell1, cell2);
    edge2 = new Edge(cell3, cell4);
    edge3 = new Edge(cell5, cell6);
    edge4 = new Edge(cell1, cell3);
    ec = new EdgeComparator();

    hash = new HashMap<Cell, Cell>();
  }

  // runs the game! (100x60)
  void testGame1(Tester t) {
    initData();
    maze1.bigBang(1000, 600, .01);
  }

  // isHorizontal tests
  void testIsHorizontal(Tester t) {
    initData();
    t.checkExpect(edge1.isHorizontal(), true);
    t.checkExpect(edge2.isHorizontal(), false);
    t.checkExpect(edge3.isHorizontal(), false);
  }

  // drawEdge tests
  void testDrawEdge(Tester t) {
    initData();
    t.checkExpect(edge1.drawEdge(),
        new RectangleImage(4, 1, OutlineMode.SOLID, Color.BLACK).movePinhole(0, 2));
    t.checkExpect(edge2.drawEdge(),
        new RectangleImage(1, 30, OutlineMode.SOLID, Color.BLACK).movePinhole(15, 0));
    t.checkExpect(edge3.drawEdge(),
        new RectangleImage(1, 20, OutlineMode.SOLID, Color.BLACK).movePinhole(7, 0));
  }

  // compare tests
  void testCompare(Tester t) {
    initData();

    for (int i = 0; i < maze2.edgeList.size(); i += 1) {
      t.checkExpect(maze2.edgeList.get(i).weight, maze2.edgeList.get(i).weight);
    }

    maze2.edgeList.sort(ec);

    for (int i = 0; i < maze2.edgeList.size(); i += 1) {
      t.checkExpect(maze2.edgeList.get(i).weight, maze2.worklist.get(i).weight);
    }
  }

  // drawCell tests
  void testDrawCell(Tester t) {
    initData();
    t.checkExpect(mtCell.drawCell(), new EmptyImage());
    t.checkExpect(cell1.drawCell(), new RectangleImage(4, 4, OutlineMode.SOLID, Color.GRAY));
    t.checkExpect(cell2.drawCell(), new RectangleImage(6, 8, OutlineMode.SOLID, Color.GRAY));
  }

  // tests diffX
  void testDiffX(Tester t) {
    initData();
    t.checkExpect(mtCell.diffX(cell1), 0);
    t.checkExpect(cell1.diffX(cell1), 0);
    t.checkExpect(cell1.diffX(cell2), -1);
    t.checkExpect(cell2.diffX(cell1), 1);
    t.checkExpect(cell3.diffX(cell2), 4);

  }

  // tests diffY
  void testDiffY(Tester t) {
    initData();
    t.checkExpect(mtCell.diffY(cell1), 0);
    t.checkExpect(cell1.diffY(cell1), 0);
    t.checkExpect(cell1.diffY(cell2), -2);
    t.checkExpect(cell2.diffY(cell1), 2);
    t.checkExpect(cell3.diffY(cell2), -2);
  }

  // setRight tests
  void setRight(Tester t) {
    initData();

    // nothing to test in the empty case since there are no fields

    t.checkExpect(cell1.bottom, new MTCell());
    t.checkExpect(cell1.top, new MTCell());
    t.checkExpect(cell1.right, new MTCell());
    t.checkExpect(cell1.left, new MTCell());
    t.checkExpect(cell1.edgeBottom, new Edge(cell1, cell1));
    t.checkExpect(cell1.edgeTop, new Edge(cell1, cell1));
    t.checkExpect(cell1.edgeLeft, new Edge(cell1, cell1));
    t.checkExpect(cell1.edgeRight, new Edge(cell1, cell1));

    t.checkExpect(cell2.bottom, new MTCell());
    t.checkExpect(cell2.top, new MTCell());
    t.checkExpect(cell2.right, new MTCell());
    t.checkExpect(cell2.left, new MTCell());
    t.checkExpect(cell2.edgeBottom, new Edge(cell2, cell2));
    t.checkExpect(cell2.edgeTop, new Edge(cell2, cell2));
    t.checkExpect(cell2.edgeLeft, new Edge(cell2, cell2));
    t.checkExpect(cell2.edgeRight, new Edge(cell2, cell2));

    t.checkExpect(cell1.edges.size(), 0);
    t.checkExpect(cell1.adjacentCells.size(), 0);
    t.checkExpect(cell2.edges.size(), 0);
    t.checkExpect(cell2.adjacentCells.size(), 0);

    cell1.setRight(edge1, cell2);

    t.checkExpect(cell1.bottom, new MTCell());
    t.checkExpect(cell1.top, new MTCell());
    t.checkExpect(cell1.right, cell2);
    t.checkExpect(cell1.left, new MTCell());
    t.checkExpect(cell1.edgeBottom, new Edge(cell1, cell1));
    t.checkExpect(cell1.edgeTop, new Edge(cell1, cell1));
    t.checkExpect(cell1.edgeLeft, new Edge(cell1, cell1));
    t.checkExpect(cell1.edgeRight, edge1);

    t.checkExpect(cell2.bottom, new MTCell());
    t.checkExpect(cell2.top, new MTCell());
    t.checkExpect(cell2.right, new MTCell());
    t.checkExpect(cell2.left, cell1);
    t.checkExpect(cell2.edgeBottom, new Edge(cell2, cell2));
    t.checkExpect(cell2.edgeTop, new Edge(cell2, cell2));
    t.checkExpect(cell2.edgeLeft, edge1);
    t.checkExpect(cell2.edgeRight, new Edge(cell2, cell2));

    t.checkExpect(cell1.edges.size(), 1);
    t.checkExpect(cell1.adjacentCells.size(), 1);
    t.checkExpect(cell2.edges.size(), 1);
    t.checkExpect(cell2.adjacentCells.size(), 1);
  }

  // setBottom tests
  void testSetBottom(Tester t) {
    initData();

    // nothing to test in the empty case since there are no fields and nothing is
    // being done

    t.checkExpect(cell1.bottom, new MTCell());
    t.checkExpect(cell1.top, new MTCell());
    t.checkExpect(cell1.right, new MTCell());
    t.checkExpect(cell1.left, new MTCell());
    t.checkExpect(cell1.edgeBottom, null);
    t.checkExpect(cell1.edgeTop, null);
    t.checkExpect(cell1.edgeLeft, null);
    t.checkExpect(cell1.edgeRight, null);

    t.checkExpect(cell2.bottom, new MTCell());
    t.checkExpect(cell2.top, new MTCell());
    t.checkExpect(cell2.right, new MTCell());
    t.checkExpect(cell2.left, new MTCell());
    t.checkExpect(cell2.edgeBottom, null);
    t.checkExpect(cell2.edgeTop, null);
    t.checkExpect(cell2.edgeLeft, null);
    t.checkExpect(cell2.edgeRight, null);

    t.checkExpect(cell1.edges.size(), 0);
    t.checkExpect(cell1.adjacentCells.size(), 0);
    t.checkExpect(cell2.edges.size(), 0);
    t.checkExpect(cell2.adjacentCells.size(), 0);

    cell1.setBottom(edge1, cell2);

    t.checkExpect(cell1.bottom, cell2);
    t.checkExpect(cell1.top, new MTCell());
    t.checkExpect(cell1.right, new MTCell());
    t.checkExpect(cell1.left, new MTCell());
    t.checkExpect(cell1.edgeBottom, edge1);
    t.checkExpect(cell1.edgeTop, null);
    t.checkExpect(cell1.edgeLeft, null);
    t.checkExpect(cell1.edgeRight, null);

    t.checkExpect(cell2.bottom, new MTCell());
    t.checkExpect(cell2.top, cell1);
    t.checkExpect(cell2.right, new MTCell());
    t.checkExpect(cell2.left, new MTCell());
    t.checkExpect(cell2.edgeBottom, null);
    t.checkExpect(cell2.edgeTop, edge1);
    t.checkExpect(cell2.edgeLeft, null);
    t.checkExpect(cell2.edgeRight, null);

    t.checkExpect(cell1.edges.size(), 1);
    t.checkExpect(cell1.adjacentCells.size(), 1);
    t.checkExpect(cell2.edges.size(), 1);
    t.checkExpect(cell2.adjacentCells.size(), 1);
  }

  // removeEdge tests
  void testRemoveEdge(Tester t) {

    this.initData();
    ArrayList<Edge> list1 = new ArrayList<Edge>();
    list1.add(edge1);
    list1.add(edge2);
    list1.add(edge3);
    cell1.edges = list1;

    // nothing to test in the empty case since there are no fields

    t.checkExpect(cell1.edges.contains(edge1), true);
    cell1.removeEdge(edge1);

    t.checkExpect(cell1.edges.contains(edge1), false);
    t.checkExpect(cell1.edges.contains(edge2), true);
    t.checkExpect(cell1.edges.contains(edge3), true);

    cell1.removeEdge(edge2);

    t.checkExpect(cell1.edges.contains(edge1), false);
    t.checkExpect(cell1.edges.contains(edge2), false);
    t.checkExpect(cell1.edges.contains(edge3), true);
  }

  // wasVisited tests
  void testGotVisited(Tester t) {
    initData();

    // no way to test for an empty cell since there are no fields

    t.checkExpect(cell1.visited, false);
    cell1.gotVisited();
    t.checkExpect(cell1.visited, true);

    t.checkExpect(cell2.visited, false);
    cell2.gotVisited();
    t.checkExpect(cell2.visited, true);
  }

  // changeColor tests
  void testChangeColor(Tester t) {
    initData();

    t.checkExpect(cell1.color, Color.gray);
    t.checkExpect(cell2.color, Color.gray);
    t.checkExpect(cell3.color, Color.gray);

    cell1.changeColor(Color.orange);
    cell2.changeColor(Color.magenta);
    cell3.changeColor(Color.CYAN);

    t.checkExpect(cell1.color, Color.orange);
    t.checkExpect(cell2.color, Color.magenta);
    t.checkExpect(cell3.color, Color.cyan);

    cell1.changeColor(Color.red);

    t.checkExpect(cell1.color, Color.red);
  }

  // tests sameCoords
  void testSameCoords(Tester t) {
    initData();
    Cell testCell = new Cell(0, 0, 0, 0);
    Cell testCell2 = new Cell(1, 2, 0, 0);
    t.checkExpect(mtCell.sameCoords(testCell), false);
    t.checkExpect(cell1.sameCoords(testCell), true);
    t.checkExpect(cell1.sameCoords(testCell2), false);
    t.checkExpect(cell2.sameCoords(testCell), false);
    t.checkExpect(cell2.sameCoords(testCell2), true);
  }

  // tests setEqualEdges
  void testSetEqualEdges(Tester t) {
    initData();
    cell1.edgeTop = edge1;
    cell1.edgeBottom = edge2;
    cell1.edgeRight = edge3;

    // nothing to test in the empty case since there are no fields

    t.checkExpect(cell1.edgeTop.equals(cell2.edgeTop), false);
    t.checkExpect(cell1.edgeBottom.equals(cell2.edgeBottom), false);
    t.checkExpect(cell1.edgeRight.equals(cell2.edgeRight), false);

    cell2.setEqualEdges(cell1);

    t.checkExpect(cell1.edgeTop.equals(cell2.edgeTop), true);
    t.checkExpect(cell1.edgeBottom.equals(cell2.edgeBottom), true);
    t.checkExpect(cell1.edgeRight.equals(cell2.edgeRight), true);
  }

  // tests isXEqual
  void testIsXEqual(Tester t) {
    initData();
    t.checkExpect(cell1.isXEqual(0), true);
    t.checkExpect(cell1.isXEqual(2), false);
    t.checkExpect(cell2.isXEqual(1), true);
    t.checkExpect(cell2.isXEqual(0), false);
  }

  // tests isYEqual
  void testIsYEqual(Tester t) {
    initData();
    t.checkExpect(cell1.isYEqual(0), true);
    t.checkExpect(cell1.isYEqual(2), false);
    t.checkExpect(cell2.isYEqual(2), true);
    t.checkExpect(cell2.isYEqual(0), false);
  }

  // tests setNeighbors
  void testSetNeighbors(Tester t) {
    initData();
    // nothing to test in the empty case

    cell1.setBottom(edge1, cell2);
    cell1.setRight(edge2, cell3);
    cell1.edges.clear();
    cell2.edges.clear();
    cell3.edges.clear();
    t.checkExpect(cell1.neighbors.size(), 0);
    t.checkExpect(cell2.neighbors.size(), 0);
    t.checkExpect(cell3.neighbors.size(), 0);
    cell1.setNeighbors();
    cell2.setNeighbors();
    cell3.setNeighbors();
    t.checkExpect(cell1.neighbors.size(), 2);
    t.checkExpect(cell2.neighbors.size(), 1);
    t.checkExpect(cell3.neighbors.size(), 1);

    // check what happens if there are not adjacent cells
    initData();
    t.checkExpect(cell1.neighbors.size(), 0);
    cell1.setNeighbors();
    t.checkExpect(cell1.neighbors.size(), 0);
  }

  // test setX and setY
  void testSetXY(Tester t) {
    initData();
    // nothing to test in the empty case, since nothing is being changed
    t.checkExpect(cell1.x, 0);
    cell1.setX(1);
    t.checkExpect(cell1.x, 1);
    cell1.setX(-1);
    t.checkExpect(cell1.x, 0);

    t.checkExpect(cell1.y, 0);
    cell1.setY(1);
    t.checkExpect(cell1.y, 1);
    cell1.setY(-1);
    t.checkExpect(cell1.y, 0);
  }

  // test containsBottomEdge, containsTopEdge, containsRightEdge, containsLeftEdge
  void testContainsEdges(Tester t) {
    initData();
    t.checkExpect(mtCell.containsBottomEdge(), false);
    t.checkExpect(mtCell.containsTopEdge(), false);
    t.checkExpect(mtCell.containsRightEdge(), false);
    t.checkExpect(mtCell.containsLeftEdge(), false);

    cell1.edgeTop = edge1;
    cell1.edgeBottom = edge2;
    cell1.edgeRight = edge3;
    cell1.edgeLeft = edge4;
    cell1.edges.add(cell1.edgeTop);
    cell1.edges.add(cell1.edgeBottom);
    cell1.edges.add(cell1.edgeLeft);
    cell1.edges.add(cell1.edgeRight);

    t.checkExpect(cell1.containsBottomEdge(), true);
    t.checkExpect(cell1.containsTopEdge(), true);
    t.checkExpect(cell1.containsRightEdge(), true);
    t.checkExpect(cell1.containsLeftEdge(), true);

    for (int i = 3; i > -1; i -= 1) {
      cell1.edges.remove(i);
    }

    t.checkExpect(cell1.containsBottomEdge(), false);
    t.checkExpect(cell1.containsTopEdge(), false);
    t.checkExpect(cell1.containsRightEdge(), false);
    t.checkExpect(cell1.containsLeftEdge(), false);
  }

  // union tests
  void testUnion(Tester t) {
    initData();
    maze6.union(hash, cell5, cell6);
    t.checkExpect(hash.containsKey(cell5), true);
    t.checkExpect(hash.containsKey(cell6), false);
    t.checkExpect(hash.containsKey(cell4), false);
    t.checkExpect(hash.containsKey(cell3), false);

    maze6.union(hash, cell6, cell3);
    t.checkExpect(hash.containsKey(cell6), true);
    t.checkExpect(hash.containsKey(cell5), true);
    t.checkExpect(hash.containsKey(cell4), false);
    t.checkExpect(hash.containsKey(cell3), false);
  }

  // find tests
  void testFind(Tester t) {
    initData();
    maze5.union(hash, cell3, cell2);
    t.checkExpect(maze5.find(hash, cell1), cell1);
    t.checkExpect(maze5.find(hash, cell3), cell2);
    t.checkExpect(maze5.find(hash, cell2), cell2);
  }

  // initGridLists tests
  void testInitGridLists(Tester t) {
    initData();

    t.checkExpect(maze1.grid.size(), 60);
    maze1.initGridLists();
    t.checkExpect(maze1.grid.size(), 120);

    t.checkExpect(maze2.grid.size(), 4);
    maze2.initGridLists();
    t.checkExpect(maze2.grid.size(), 8);

    t.checkExpect(maze3.grid.size(), 4);
    maze3.initGridLists();
    t.checkExpect(maze3.grid.size(), 8);
  }

  // kruskal tests
  void testKruskal(Tester t) {
    initData();

    edge1.weight = 1;
    maze4.edgeList.add(edge1);
    t.checkExpect(maze4.edgeList.contains(edge1), true);
    maze4.kruskal();
    t.checkExpect(maze4.edgeList.contains(edge1), false);

    edge1.weight = -57;
    maze7.edgeList.add(edge1);
    t.checkExpect(maze7.edgeList.contains(edge1), true);
    maze7.kruskal();
    t.checkExpect(maze7.edgeList.contains(edge1), false);

    edge1.weight = 999999999;
    maze8.edgeList.add(edge1);
    t.checkExpect(maze8.edgeList.contains(edge1), true);
    maze8.kruskal();
    t.checkExpect(maze8.edgeList.contains(edge1), true);
  }

  // displayMessages tests
  void testDisplayMessages(Tester t) {
    initData();
    maze1.player.sameCoords(maze1.start);
    maze1.mode = 0;
    maze1.keyPressed = true;
    WorldScene s2 = s1;
    s2.placeImageXY(
        new TextImage(
            "Press '1' for DFS. Press '2' for BFS. Continue with WASD for"
                + " manual solving. Press 'r' to reset the maze. Press 'q' to quit.",
            Color.lightGray),
        1001 / 2, 601 / 2);
    t.checkExpect(maze1.displayMessages(s1), s2);

    initData();
    maze1.player.sameCoords(maze1.end);
    WorldScene s3 = s1;
    s3.placeImageXY(new TextImage(
        "You win! Press 'r' to generate a new " + 100 + "x" + 60 + " maze, or 'q' to quit.",
        Color.lightGray), 1001 / 2, 601 / 2);
  }

  // makeScene tests
  void testMakeScene(Tester t) {
    initData();
    for (ArrayList<Cell> row : maze1.grid) {
      for (Cell cell : row) {
        // draw the cell
        s1.placeImageXY(cell.drawCell(), (1000 / maze1.width) * cell.x + (1000 / maze1.width) / 2,
            (600 / maze1.length) * cell.y + (600 / maze1.length) / 2);
        if (cell.edgeBottom != null && cell.edges.contains(cell.edgeBottom)) {
          s1.placeImageXY(cell.edgeBottom.drawEdge(),
              (1000 / maze1.width) * cell.x + (1000 / maze1.width) / 2,
              (600 / maze1.length) * cell.y + ((1800 / maze1.length) / 2));
        }
        if (cell.edgeRight != null && cell.edges.contains(cell.edgeRight)) {
          s1.placeImageXY(cell.edgeRight.drawEdge(),
              (1000 / maze1.width) * cell.x + (3000 / maze1.width) / 2,
              (600 / maze1.length) * cell.y + ((600 / maze1.length) / 2));
        }
      }
    }
    if (maze1.player.sameCoords(maze1.start) && maze1.mode == 0 && !maze1.keyPressed) {
      s1.placeImageXY(new TextImage(
          "Press '1' for DFS. Press '2' for BFS. Continue with WASD for"
              + " manual solving. Press 'r' to reset the maze. Press 'q' to quit.",
          Color.lightGray), 1001 / 2, 601 / 2);
    }
    s1.placeImageXY(maze1.player.drawCell(),
        (1000 / maze1.width) * maze1.player.x + (1000 / maze1.width) / 2,
        (600 / maze1.length) * maze1.player.y + (600 / maze1.length) / 2);
    t.checkExpect(this.maze1.makeScene(), s1);
  }

  // reset tests
  void testReset(Tester t) {
    initData();
    // give maze1 some arbitrary values to work with for testing purposes
    maze1.mode = 2;
    maze1.keyPressed = true;
    maze1.cheatCode = true;
    maze1.grid.add(new ArrayList<Cell>());
    maze1.path.add(cell1);
    t.checkExpect(maze1.mode, 2);
    t.checkExpect(maze1.keyPressed, true);
    t.checkExpect(maze1.cheatCode, true);
    t.checkExpect(maze1.grid.size(), 61); // since it's a 100x60 board and we're adding another row
    t.checkExpect(maze1.grid.contains(new ArrayList<Cell>()), true);
    t.checkExpect(maze1.path.size(), 1);
    t.checkExpect(maze1.path.contains(cell1), true);

    maze1.reset();

    t.checkExpect(maze1.mode, 0);
    t.checkExpect(maze1.keyPressed, false);
    t.checkExpect(maze1.cheatCode, false);
    t.checkExpect(maze1.grid.size(), 60);
    t.checkExpect(maze1.grid.contains(new ArrayList<Cell>()), false);
    t.checkExpect(maze1.path.size(), 0);
    t.checkExpect(maze1.path.contains(cell1), false);
  }

  // onKeyEvent tests
  void testOnKeyEvent(Tester t) {
    initData();
    maze1.onKeyEvent("0");
    t.checkExpect(maze1.mode, 0);
    maze1.onKeyEvent("1");
    t.checkExpect(maze1.mode, 1);
    maze1.onKeyEvent("2");
    t.checkExpect(maze1.mode, 2);

    // stays same as current mode if random key or number out of range is pressed
    maze1.onKeyEvent("3");
    t.checkExpect(maze1.mode, 2);
    maze1.onKeyEvent("g");
    t.checkExpect(maze1.mode, 2);

    maze1.mode = 2;
    maze1.cheatCode = true;
    maze1.grid.add(new ArrayList<Cell>());
    maze1.path.add(cell1);
    t.checkExpect(maze1.mode, 2);
    t.checkExpect(maze1.keyPressed, true);
    t.checkExpect(maze1.cheatCode, true);
    t.checkExpect(maze1.grid.size(), 61); // since it's a 100x60 board and we're adding another row
    t.checkExpect(maze1.grid.contains(new ArrayList<Cell>()), true);
    t.checkExpect(maze1.path.size(), 1);
    t.checkExpect(maze1.path.contains(cell1), true);

    maze1.onKeyEvent("r");

    t.checkExpect(maze1.mode, 0);
    t.checkExpect(maze1.keyPressed, false);
    t.checkExpect(maze1.cheatCode, false);
    t.checkExpect(maze1.grid.size(), 60);
    t.checkExpect(maze1.grid.contains(new ArrayList<Cell>()), false);
    t.checkExpect(maze1.path.size(), 0);
    t.checkExpect(maze1.path.contains(cell1), false);

    initData();
    maze1.mode = 0;
    maze1.player.edges.remove(maze1.player.edgeRight);
    maze1.start.edges.remove(maze1.start.edgeRight);
    maze1.player.edges.remove(maze1.player.edgeBottom);
    maze1.start.edges.remove(maze1.start.edgeBottom);
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("d");
    t.checkExpect(maze1.player.x, 1);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("a");
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("s");
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 1);
    maze1.onKeyEvent("w");
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);

    maze1.onKeyEvent("c");
    for (int i = 0; i < maze1.path.size(); i += 1) {
      t.checkExpect(maze1.path.get(i).color, Color.cyan);
    }
    maze1.onKeyEvent("c"); // test the toggle
    for (int i = 0; i < maze1.path.size(); i += 1) {
      t.checkExpect(maze1.path.get(i).color, Color.gray);
    }
    maze1.onKeyEvent("c"); // test the toggle
    for (int i = 0; i < maze1.path.size(); i += 1) {
      t.checkExpect(maze1.path.get(i).color, Color.cyan);
    }

    initData();
    maze1.mode = 1;
    maze1.onKeyEvent("w"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("a"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("s"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("d"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);

    maze1.onKeyEvent("c"); // nothing should change
    for (int i = 0; i < maze1.path.size(); i += 1) {
      t.checkExpect(maze1.path.get(i).color, Color.gray);
    }

    initData();
    maze1.player.edges.add(maze1.player.edgeRight);
    maze1.start.edges.add(maze1.start.edgeRight);
    maze1.player.edges.add(maze1.player.edgeBottom);
    maze1.start.edges.add(maze1.start.edgeBottom);
    maze1.onKeyEvent("w"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("a"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("s"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
    maze1.onKeyEvent("d"); // nothing should change
    t.checkExpect(maze1.player.x, 0);
    t.checkExpect(maze1.player.y, 0);
  }

  // test exceptions
  void testExceptions(Tester t) {
    initData();
    t.checkConstructorException(
        new IllegalArgumentException("I mean, what did you think was gonna happen?"), "MazeWorld",
        0, 0);
    t.checkConstructorException(
        new IllegalArgumentException("I mean, what did you think was gonna happen?"), "MazeWorld",
        0, 60);
    t.checkConstructorException(
        new IllegalArgumentException("I mean, what did you think was gonna happen?"), "MazeWorld",
        100, 1);
    t.checkConstructorException(
        new IllegalArgumentException("I mean, what did you think was gonna happen?"), "MazeWorld",
        1, 60);
    t.checkConstructorException(
        new IllegalArgumentException("I mean, what did you think was gonna happen?"), "MazeWorld",
        1, 1);
    t.checkConstructorException(
        new IllegalArgumentException("Board width cannot be more than 100 cells"), "MazeWorld", 101,
        60);
    t.checkConstructorException(
        new IllegalArgumentException("Board length cannot be more than 60 cells"), "MazeWorld", 100,
        61);

    t.checkException(new IllegalArgumentException("Can't have a negative x value"), cell1, "setX",
        -1);
    t.checkException(new IllegalArgumentException("Can't have a negative y value"), cell1, "setY",
        -1);
  }

  // tests dfs
  void testSearchDFS(Tester t) {
    initData();
    DFS dfs = new DFS(maze1.start);
    t.checkExpect(dfs.visited.size(), 0);
    dfs.search(maze1);
    t.checkExpect(dfs.visited.size() == 0, false); // can't find the exact size but it wouldn't be
    // empty
  }

  // tests bfs
  void testSearchBFS(Tester t) {
    initData();
    BFS bfs = new BFS(maze1.start);
    t.checkExpect(bfs.visited.size(), 0);
    bfs.search(maze1);
    t.checkExpect(bfs.visited.size() == 0, false); // can't find the exact size but it wouldn't be
    // empty
  }

  // tests onTick
  void testOnTick(Tester t) {
    initData();
    maze1.dSearching = true;
    t.checkExpect(maze1.dSearching, true);
    maze1.onTick();
    t.checkExpect(maze1.dSearching, false);
  }
}