import java.awt.Color;
import java.util.ArrayList;

import javalib.worldimages.*;

// to represent an interface of cells for the maze game
interface ICell {

  // draw this ICell
  WorldImage drawCell();

  // calculate difference of x positions
  int diffX(Cell c);

  // calculate difference of y positions
  int diffY(Cell c);

  // set the cell to the right of this ICell and give it its corresponding edge
  void setRight(Edge e, Cell c);

  // set the cell under this ICell and give it its corresponding edge
  void setBottom(Edge e, Cell c);

  // updates the ICell if it got visited
  void gotVisited();
  
  // remove e from the edge list
  void removeEdge(Edge e);

  // change the color of this ICell
  void changeColor(Color color);

  // does this ICell have the same coordinates has that cell?
  boolean sameCoords(Cell other);

  // sets this ICell to have the same edges as that cell
  void setEqualEdges(Cell other);

  // is the x-coordinate of this ICell equal to that value?
  boolean isXEqual(int val);

  // is the y-coordinate of this ICell equal to that value?
  boolean isYEqual(int val);

  // set the neighbors of this ICell
  void setNeighbors();

  // set the x variable to whatever it is plus this num
  void setX(int num);

  // set the y variable to whatever it is plus this num
  void setY(int num);

  // is the top edge in the cell's list of edges?
  boolean containsTopEdge();

  // is the bottom edge in the cell's list of edges?
  boolean containsBottomEdge();

  // is the left edge in the cell's list of edges?
  boolean containsLeftEdge();

  // is the right edge in the cell's list of edges?
  boolean containsRightEdge();
  
}

// to represent an empty cell for the maze game
class MTCell implements ICell {
  MTCell() {
  }

  // draw this empty cell
  public WorldImage drawCell() {
    return new EmptyImage();
  }

  // difference of x between an empty cell and a non-empty cell
  public int diffX(Cell c) {
    return 0;
  }

  // difference of y between an empty cell and a non-empty cell
  public int diffY(Cell c) {
    return 0;
  }

  // set the cell to the right of this empty cell and give it its empty edge
  // EFFECT: nothing in the empty case
  public void setRight(Edge e, Cell c) {
    // this will never happen
  }

  // set the cell under this empty cell and give it its empty edge
  // EFFECT: nothing in the empty case
  public void setBottom(Edge e, Cell c) {
    // this will never happen
  }

  // updates the empty cell if it was visited
  // EFFECT: nothing will happen in the empty case
  public void gotVisited() {
    // this will never happen
  }

  // change the color of this empty cell
  // EFFECT: nothing will happen in the empty case
  public void changeColor(Color color) {
    // this will never happen
  }

  // does this non-empty cell have the same coordinates as that cell?
  public boolean sameCoords(Cell other) {
    return false;
  }

  // changes this empty cell to have the same edges as that cell
  // EFFECT: nothing, since it's an empty cell
  public void setEqualEdges(Cell other) {
    // this will never happen
  }

  // is the x-coordinate of this empty cell equal to that value?
  public boolean isXEqual(int val) {
    return false;
  }

  // is the y-coordinate of this empty cell equal to that value?
  public boolean isYEqual(int val) {
    return false;
  }

  // sets the neighbors of this empty cell
  // EFFECT: nothing, since it's an empty cell
  public void setNeighbors() {
    // this will never happen
  }

  // set the x variable to whatever it is plus num
  // EFFECT: nothing, since it's an empty cell
  public void setX(int num) {
    // this will never happen
  }

  // set the y variable to whatever it is plus num
  // EFFECT: nothing, since it's an empty cell
  public void setY(int num) {
    // this will never happen

  }

  // is this top edge in this empty cell's list of edges?
  public boolean containsTopEdge() {
    return false;
  }

  // is this bottom edge in this empty cell's list of edges?
  public boolean containsBottomEdge() {
    return false;
  }

  // is this left edge in this empty cell's list of edges?
  public boolean containsLeftEdge() {
    return false;
  }

  // is this right edge in this empty cell's list of edges?
  public boolean containsRightEdge() {
    return false;
  }

  // remove e from this empty cell's edge list
  // EFFECT: nothing, since it's an empty cell
  public void removeEdge(Edge e) {
    // this will never happen
  }
  
  public String toString() {
    return "EMPTY CELL";
  }
}

//to represent a non-empty cell for the maze game
class Cell implements ICell {
  int x;
  int y;
  int width;
  int length;
  ICell left;
  ICell right;
  ICell top;
  ICell bottom;
  ArrayList<Cell> adjacentCells;
  Color color;
  Edge edgeLeft;
  Edge edgeTop;
  Edge edgeRight;
  Edge edgeBottom;
  boolean edgesInitialized;
  ArrayList<Edge> edges;
  boolean visited;
  ArrayList<Cell> neighbors;

  Cell(int x, int y, int width, int length) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.length = length;
    this.adjacentCells = new ArrayList<Cell>();
    this.neighbors = new ArrayList<Cell>();
    this.left = new MTCell();
    this.right = new MTCell();
    this.top = new MTCell();
    this.bottom = new MTCell();
    this.edges = new ArrayList<Edge>();
    this.visited = false;
    this.edgesInitialized = false;
    this.color = Color.gray;

  }

  // set the cell right of this one and add the right edge, also assign this cell
  // to that cell
  // EFFECT: adds a right cell to this one, adds it to the list of adjacent cells,
  // adds a new edge,
  // adds that to the list of edges
  public void setRight(Edge e, Cell c) {
    this.right = c;
    c.left = this;
    this.edgeRight = e;
    c.edgeLeft = e;
    // to avoid duplicates, just in case
    if (!this.edges.contains((e))) {
      this.edges.add(e);
      this.adjacentCells.add(c);
    }
    if (!c.edges.contains(e)) {
      c.edges.add(e);
      c.adjacentCells.add(this);
    }
    this.edgesInitialized = true;
  }

  // set the cell below this one and add the bottom edge, also assign this cell to
  // that cell
  // EFFECT: adds a bottom cell to this one, adds it to the list of adjacent
  // cells, adds a new edge,
  // adds that to the list of edges
  public void setBottom(Edge e, Cell c) {
    this.bottom = c;
    c.top = this;
    this.edgeBottom = e;
    c.edgeTop = e;
    // to avoid duplicates, just in case
    if (!this.edges.contains(e)) {
      this.edges.add(e);
      this.adjacentCells.add(c);
    }
    if (!c.edges.contains(e)) {
      c.edges.add(e);
      c.adjacentCells.add(this);
    }
    this.edgesInitialized = true;
  }

  // updates the non-empty cell if it was visited
  // EFFECT: updates visited boolean
  public void gotVisited() {
    this.visited = true;
    this.color = Color.MAGENTA;
  }

  // draw this non-empty cell
  public WorldImage drawCell() {
    return new RectangleImage(this.width, this.length, OutlineMode.SOLID, this.color);
  }

  // removes an edge from this cell's list of edges. that edge is still assigned
  // to the cell
  // via a directional edge field, which will be helpful in setting neighbors
  // EFFECT: remove an edge from the edges field
  public void removeEdge(Edge e) {
    this.edges.remove(e);
  }

  // calculate difference of x between these two cells
  public int diffX(Cell c) {
    return this.x - c.x;
  }

  // calculate difference of y between these two cells
  public int diffY(Cell c) {
    return this.y - c.y;
  }

  // to change the color of this non-empty cell
  // EFFECT: update the color field to that color
  public void changeColor(Color color) {
    this.color = color;
  }

  // does this non-empty cell have the same coordinates as that cell?
  public boolean sameCoords(Cell other) {
    return this.x == other.x && this.y == other.y;
  }

  // changes this cell to have the same edges as that cell
  // EFFECT: mutate this cell's edges to be the same as the other cell
  public void setEqualEdges(Cell other) {
    this.edges = other.edges;
    this.edgeRight = other.edgeRight;
    this.edgeLeft = other.edgeLeft;
    this.edgeBottom = other.edgeBottom;
    this.edgeTop = other.edgeTop;
  }

  // is the x-coordinate of this non-empty cell equal to that value?
  public boolean isXEqual(int val) {
    return this.x == val;
  }

  // is the y-coordinate of this non-empty cell equal to that value?
  public boolean isYEqual(int val) {
    return this.y == val;
  }

  // sets the neighbors, that is, adjacent cells with no edge between them, of
  // this non-empty cell
  // EFFECT: update the neighbors field
  public void setNeighbors() {
    for (Cell c : this.adjacentCells) {
      if (!this.containsBottomEdge() && !c.containsTopEdge() && this.edgeBottom == c.edgeTop
          && this.edgeBottom != null) {
        this.neighbors.add(c);
      }
      else if (!this.containsRightEdge() && !c.containsLeftEdge() && this.edgeRight == c.edgeLeft
          && this.edgeRight != null) {
        this.neighbors.add(c);
      }
      else if (!this.containsLeftEdge() && !c.containsRightEdge() && this.edgeLeft == c.edgeRight
          && this.edgeLeft != null) {
        this.neighbors.add(c);
      }
      else if (!this.containsTopEdge() && !c.containsBottomEdge() && this.edgeTop == c.edgeBottom
          && this.edgeTop != null) {
        this.neighbors.add(c);
      }
    }
  }

  // set the x variable to whatever it is plus num
  // EFFECT: adds num to this.x
  public void setX(int num) {
    if (this.x == 0 && num < 0) {
      throw new IllegalArgumentException("Can't have a negative x value");
    }
    this.x = this.x + num;

  }

  // set the y variable to whatever it is plus num
  // EFFECT: adds num to this.y
  public void setY(int num) {
    if (this.y == 0 && num < 0) {
      throw new IllegalArgumentException("Can't have a negative y value");
    }
    this.y = this.y + num;
  }

  // is this top edge in this non-empty cell's list of edges?
  public boolean containsTopEdge() {
    return this.edges.contains(this.edgeTop);
  }

  // is this bottom edge in this non-empty cell's list of edges?
  public boolean containsBottomEdge() {
    return this.edges.contains(this.edgeBottom);
  }

  // is this left edge in this non-empty cell's list of edges?
  public boolean containsLeftEdge() {
    return this.edges.contains(this.edgeLeft);
  }

  // is this right edge in this non-empty cell's list of edges?
  public boolean containsRightEdge() {
    return this.edges.contains(this.edgeRight);
  }
  
  public String toString() {
    return "(" + this.x + ", " + this.y + ")";
  }
}