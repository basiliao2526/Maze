import java.util.*;
import javalib.impworld.*;
import java.awt.Color;
import javalib.worldimages.*;

// to represent the maze game
class MazeWorld extends World {
  int width;
  int length;
  int mode; // to switch between manual, DFS, and BFS (0 for manual, 1 for DFS, 2 for BFS)
  int cells;
  boolean keyPressed;
  boolean endGame;
  boolean cheatCode;
  DFS dfs;
  BFS bfs;
  Cell start;
  Cell end;
  Cell player;
  Collection<Cell> searchList;
  ArrayList<ArrayList<Cell>> grid;
  ArrayList<Edge> edgeList;
  LinkedList<Cell> path;
  ArrayList<Edge> worklist;
  Cell current;
  boolean dSearching;
  boolean bSearching;

  MazeWorld(int width, int length) {
    this.width = width;
    this.length = length;
    this.keyPressed = false;
    this.dSearching = false;
    this.bSearching = false;
    this.endGame = false;
    this.cheatCode = false;
    if (this.length <= 3 || this.width <= 3) {
      throw new IllegalArgumentException("I mean, what did you think was gonna happen?");
    }
    if (this.width > 100) {
      throw new IllegalArgumentException("Board width cannot be more than 100 cells");
    }
    if (this.length > 60) {
      throw new IllegalArgumentException("Board length cannot be more than 60 cells");
    }
    this.mode = 0; // default to manual
    this.grid = new ArrayList<ArrayList<Cell>>();
    this.edgeList = new ArrayList<Edge>();
    this.path = new LinkedList<Cell>();
    this.initGridLists();
    this.worklist = this.edgeList;
    this.dfs = new DFS(this.start);
    this.bfs = new BFS(this.start);
    this.start = this.grid.get(0).get(0);
    this.start.changeColor(Color.blue);
    this.current = this.start;
    this.player = new Cell(0, 0, 1000 / this.width, 600 / this.length);
    this.player.changeColor(Color.green);
    this.end = this.grid.get(this.length - 1).get(this.width - 1);
    this.end.changeColor(Color.PINK);
    this.kruskal();

    for (ArrayList<Cell> row : this.grid) {
      for (Cell cell : row) {
        cell.setNeighbors();
      }
    }
  }

  // another constructor for testing kruskal's algorithm
  MazeWorld(int width) {
    this.width = width;
    this.length = this.width;
    if (this.length <= 3 || this.width <= 3) {
      throw new IllegalArgumentException("I mean, what did you think was gonna happen?");
    }
    if (this.width > 100) {
      throw new IllegalArgumentException("Board width cannot be more than 100 cells");
    }
    if (this.length > 60) {
      throw new IllegalArgumentException("Board length cannot be more than 60 cells");
    }
    this.mode = 0; // default to manual
    this.grid = new ArrayList<ArrayList<Cell>>();
    this.edgeList = new ArrayList<Edge>();
    this.path = new LinkedList<Cell>();
    this.initGridLists();
    this.worklist = this.edgeList;
    this.start = this.grid.get(0).get(0);
    this.start.changeColor(Color.blue);
    this.end = this.grid.get(this.length - 1).get(this.width - 1);
    this.end.changeColor(Color.PINK);
  }

  // put two cells in union
  // EFFECT: map two cells together
  void union(HashMap<Cell, Cell> unions, Cell c1, Cell c2) {
    unions.put(find(unions, c1), find(unions, c2));
  }

  // to find the root cell of that hashmap
  Cell find(HashMap<Cell, Cell> unions, Cell c) {
    if (!unions.containsKey(c)) {
      return c;
    }
    if (!unions.get(c).equals(c)) {
      unions.put(c, this.find(unions, unions.get(c)));
    }
    return unions.get(c);
  }

  // to initiate the lists in the MazeWorld
  // EFFECT: update the lists in the fields for MazeWorld
  void initGridLists() {
    // create a grid of unlinked cells
    for (int i = 0; i < this.length; i += 1) {
      ArrayList<Cell> rowList = new ArrayList<Cell>();
      for (int j = 0; j < this.width; j += 1) {
        Cell newCell = new Cell(j, i, 1000 / this.width, 600 / this.length);
        rowList.add(newCell);
      }
      this.grid.add(rowList);
    }
    // link the cells by creating edges
    for (int i = 0; i < this.length; i += 1) {
      for (int j = 0; j < this.width; j += 1) {
        if (j < this.width - 1) {
          Edge rightEdge = new Edge(this.grid.get(i).get(j), this.grid.get(i).get(j + 1));
          this.edgeList.add(rightEdge);
          this.grid.get(i).get(j).setRight(rightEdge, this.grid.get(i).get(j + 1));
        }
        if (i < this.length - 1) {
          Edge bottomEdge = new Edge(this.grid.get(i).get(j), this.grid.get(i + 1).get(j));
          this.edgeList.add(bottomEdge);
          this.grid.get(i).get(j).setBottom(bottomEdge, this.grid.get(i + 1).get(j));
        }
      }
    }
  }

  // to implement Kruskal's algorithm to remove edges
  // EFFECT: remove edges from the edgeList with union-find
  void kruskal() {
    HashMap<Cell, Cell> unions = new HashMap<Cell, Cell>();
    ArrayList<Integer> minTree = new ArrayList<Integer>();
    this.worklist.sort(new EdgeComparator());
    // map every cell to itself
    for (ArrayList<Cell> row : this.grid) {
      for (Cell c : row) {
        unions.put(c, c);
      }
    }

    // while there's a worklist
    while (minTree.size() < width * length - 1) {
      Edge e = this.worklist.get(0);
      this.worklist.remove(0);

      if (find(unions, e.cell2) != find(unions, e.cell1)) {
        minTree.add(0);
        e.cell1.removeEdge(e);
        e.cell2.removeEdge(e);

        // unionize!
        union(unions, find(unions, e.cell2), find(unions, e.cell1));
      }
    }
  }

  // helper method for makeScene to display the start and end messages
  WorldScene displayMessages(WorldScene scene) {
    WorldImage text = new EmptyImage();
    if (this.player.sameCoords(this.start) && this.mode == 0 && !this.keyPressed) {
      text = new TextImage(
          "Press '1' for DFS. Press '2' for BFS. Continue with WASD for"
              + " manual solving. Press 'r' to reset the maze. Press 'q' to quit.",
          Color.lightGray);
    }
    else if (this.player.sameCoords(this.end)) {
      this.mode = 4; // prevent the player from moving once they beat the game
      this.path.clear();
      for (ArrayList<Cell> row : this.grid) {
        for (Cell cell : row) {
          cell.color = Color.gray;
        }
      }
      this.start.changeColor(Color.blue);
      this.end.changeColor(Color.pink);
      text = new TextImage("You win! Press 'r' to generate a new " + this.width + "x" + this.length
          + " maze, or 'q' to quit.", Color.lightGray);
    }
    scene.placeImageXY(text, 1001 / 2, 601 / 2);
    return scene;
  }

  // create the maze world
  public WorldScene makeScene() {
    WorldScene scene = new WorldScene(1001, 601);
    int cellWidth = 1000 / this.width;
    int cellLength = 600 / this.length;

    // draw the cells and their edges
    for (ArrayList<Cell> row : this.grid) {
      for (Cell cell : row) {

        // draw the cell
        scene.placeImageXY(cell.drawCell(), cellWidth * cell.x + cellWidth / 2,
            cellLength * cell.y + cellLength / 2);
        if (cell.edgeBottom != null && cell.edges.contains(cell.edgeBottom)) {
          scene.placeImageXY(cell.edgeBottom.drawEdge(), cellWidth * cell.x + cellWidth / 2,
              cellLength * cell.y + (3 * cellLength / 2));
        }
        if (cell.edgeRight != null && cell.edges.contains(cell.edgeRight)) {
          scene.placeImageXY(cell.edgeRight.drawEdge(), cellWidth * cell.x + (3 * cellWidth / 2),
              cellLength * cell.y + cellLength / 2);
        }
      }
    }
    this.displayMessages(scene);

    scene.placeImageXY(player.drawCell(), cellWidth * player.x + cellWidth / 2,
        cellLength * player.y + cellLength / 2);
    if (this.endGame) {
      scene.placeImageXY(new RectangleImage(1001, 601, OutlineMode.SOLID, Color.PINK), 1001 / 2,
          601 / 2);
      scene.placeImageXY(new TextImage("peace out forever fundies", Color.white), 1001 / 2,
          601 / 2);
    }

    return scene;
  }

  // resets the board
  // EFFECT: reinitializes the constructor
  void reset() {
    this.mode = 0; // default to manual
    this.keyPressed = false;
    this.endGame = false;
    this.cheatCode = false;
    this.dSearching = false;
    this.bSearching = false;
    this.grid = new ArrayList<ArrayList<Cell>>();
    this.edgeList = new ArrayList<Edge>();
    this.path = new LinkedList<Cell>();
    this.initGridLists();
    this.worklist = this.edgeList;
    this.start = this.grid.get(0).get(0);
    this.start.changeColor(Color.blue);
    this.current = this.start;
    this.dfs = new DFS(this.start);
    this.bfs = new BFS(this.start);
    this.player = new Cell(0, 0, 1000 / this.width, 600 / this.length);
    this.player.changeColor(Color.green);
    this.end = this.grid.get(this.length - 1).get(this.width - 1);
    this.end.changeColor(Color.PINK);
    this.kruskal();
    for (ArrayList<Cell> row : this.grid) {
      for (Cell cell : row) {
        cell.setNeighbors();
      }
    }
  }

  // handle key presses
  public void onKeyEvent(String key) {

    // for manual maze solving
    for (ArrayList<Cell> row : this.grid) {
      for (Cell cell : row) {
        if (this.player.sameCoords(cell)) {
          this.player.setEqualEdges(cell);
        }
      }
    }

    if (key.equals("r")) {
      // reset board
      this.reset();
    }
    if (key.equals("0")) {
      this.mode = 0; // switch to manual
      this.path.clear();
      for (ArrayList<Cell> row : this.grid) {
        for (Cell cell : row) {
          cell.color = Color.gray;
        }
      }
      this.start.changeColor(Color.blue);
      this.end.changeColor(Color.pink);
    }
    if (key.equals("1")) {
      this.current = this.start;
      this.bSearching = false;
      this.keyPressed = true;
      this.dSearching = true;
      this.mode = 1; // switch to DFS
      this.path.clear();
      for (ArrayList<Cell> row : this.grid) {
        for (Cell cell : row) {
          cell.color = Color.gray;
        }
      }
      this.start.changeColor(Color.blue);
      this.end.changeColor(Color.pink);
    }
    if (key.equals("2")) {
      this.dSearching = false;
      this.current = this.start;
      this.keyPressed = true;
      this.bSearching = true;
      this.mode = 2; // switch to BFS
      this.path.clear();
      for (ArrayList<Cell> row : this.grid) {
        for (Cell cell : row) {
          cell.color = Color.gray;
        }
      }
      this.start.changeColor(Color.blue);
      this.end.changeColor(Color.pink);
    }

    if (key.equals("w")) {
      if (this.mode == 0) {
        this.keyPressed = true;
        if (!this.player.containsTopEdge() && !this.player.isYEqual(0)) {
          this.player.setY(-1);
        }
      }
    }
    if (key.equals("a")) {
      if (this.mode == 0) {
        if (!this.player.containsLeftEdge() && !this.player.isXEqual(0)) {
          this.keyPressed = true;
          this.player.setX(-1);
        }
      }
    }
    if (key.equals("s")) {
      if (this.mode == 0) {
        if (!this.player.containsBottomEdge() && !this.player.isYEqual(this.length - 1)) {
          this.keyPressed = true;
          this.player.setY(1);
        }
      }
    }
    if (key.equals("d")) {
      if (this.mode == 0) {
        if (!this.player.containsRightEdge() && !this.player.isXEqual(this.width - 1)) {
          this.keyPressed = true;
          this.player.setX(1);
        }
      }
    }
    if (key.equals("q")) {
      this.endGame = true;
      this.endOfWorld("See you next time");
    }
    if (key.equals("c") && this.mode == 0 && !this.cheatCode) {

      LinkedList<Cell> queue = new LinkedList<>();
      HashMap<Cell, Cell> visited = new HashMap<>();
      visited.put(start, null);
      Cell current = start;
      while (current != end) {
        ArrayList<Cell> adjacents = current.neighbors;
        for (Cell c : adjacents) {
          if (!visited.containsKey(c)) {
            visited.put(c, current);
            queue.add(c);
          }
        }
        current = queue.remove();
      }
      this.path.addFirst(current);
      while (current != start) {
        current = visited.get(current);
        this.path.addFirst(current);
      }

      for (Cell c : this.path) {
        c.changeColor(Color.cyan);
      }
      this.cheatCode = true;
    }
    else if (key.equals("c") && this.mode == 0 && this.cheatCode) {
      this.path.clear();
      for (ArrayList<Cell> row : this.grid) {
        for (Cell cell : row) {
          cell.color = Color.gray;
        }
      }
      this.start.changeColor(Color.blue);
      this.end.changeColor(Color.pink);
      this.cheatCode = false;
    }
  }

  // handle updating of the world
  public void onTick() {

    if (this.mode == 1 && this.dSearching) {
      this.dfs.search(this);
      if (this.current.equals(this.start)) {
        this.dSearching = false;
      }
    }
    if (this.mode == 2 && this.bSearching) {
      this.bfs.search(this);
      if (this.current.equals(this.start)) {
        this.bSearching = false;
      }
    }
  }
}