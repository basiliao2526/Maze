import java.awt.Color;
import java.util.*;
import javalib.worldimages.*;

// to represent an edge
class Edge {
  Cell cell1;
  Cell cell2;
  int weight;
  int length;
  int width;
  Random rand;

  Edge(Cell cell1, Cell cell2) {
    this.rand = new Random();
    this.weight = this.rand.nextInt(10);
    this.length = cell1.length;
    this.width = cell1.width;
    this.cell1 = cell1;
    this.cell2 = cell2;
  }

  // is this edge horizontal or vertical?
  boolean isHorizontal() {
    return this.cell2.diffX(this.cell1) < this.cell2.diffY(this.cell1);
  }

  // draw this edge
  WorldImage drawEdge() {
    WorldImage rect;
    if (this.isHorizontal()) {
      rect = new RectangleImage(this.width, 1, OutlineMode.SOLID, Color.BLACK);
      rect = rect.movePinhole(0, this.length / 2);
    }
    else {
      rect = new RectangleImage(1, this.length, OutlineMode.SOLID, Color.BLACK);
      rect = rect.movePinhole(this.width / 2, 0);
    }
    return rect;
  }
  
  public String toString() {
    return this.cell1.toString() + " --> " + this.cell2.toString();
  }
}

//comparator for the Edge class
class EdgeComparator implements Comparator<Edge> {

  // to compare weights of the edges
  public int compare(Edge o1, Edge o2) {
    return o1.weight - o2.weight;
  }
}